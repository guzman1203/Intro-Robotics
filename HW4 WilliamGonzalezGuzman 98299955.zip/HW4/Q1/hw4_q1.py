from random import randint, randrange
import time
import math
import sys
from tokenize import Double
import numpy as np
sys.path.append('PythonAPI')

NODE_NUM = 0

RND = 3

PATH = []  # type: list[list[int]]


class Node(object):
    def __init__(self, tag, parent, data):
        self.tag = tag
        self.parent = parent  # type: Node
        self.children = []  # type: list
        self.data = data

    def get_parent(self):
        '''returns parent of node'''
        return self.parent

    def set_parent(self, parent):
        '''sets parent of node'''
        self.parent = parent

    def get_children(self):
        '''returns children of node'''
        return self.children

    def set_children(self, children):
        '''sets children of node'''
        self.children = children

    def add_child(self, child):
        '''adds child to children of node'''
        self.children.append(child)

    def get_data(self):
        '''returns data of node'''
        return self.data

    def set_value(self, data):
        '''sets data of node'''
        self.data = data

    def is_root(self):
        '''checks if node is root of tree'''
        if self.get_parent is not None:
            return False
        else:
            return True

    def is_leaf(self):
        '''checks if node is a leaf of tree'''
        if len(self.children) == 0:
            return True
        else:
            return False


try:
    import sim
except:
    print('--------------------------------------------------------------')
    print('"sim.py" could not be imported. This means very probably that')
    print('either "sim.py" or the remoteApi library could not be found.')
    print('Make sure both are in the same folder as this file,')
    print('or appropriately adjust the file "sim.py"')
    print('--------------------------------------------------------------')
    print('')


print('Program started')
sim.simxFinish(-1)  # just in case, close all opened connections
clientID = sim.simxStart('127.0.0.1', 19999, True, True,
                         5000, 5)  # Connect to CoppeliaSim
if clientID != -1:
    print('Connected to remote API server')
else:
    print('Failed connecting to remote API server')
    sys.exit('Could not connect to Vrep')

# get the handles of arm joints
err_code, armjoint1_handle = sim.simxGetObjectHandle(
    clientID, "UR5_joint1", sim.simx_opmode_blocking)
err_code, armjoint2_handle = sim.simxGetObjectHandle(
    clientID, "UR5_joint2", sim.simx_opmode_blocking)
err_code, armjoint3_handle = sim.simxGetObjectHandle(
    clientID, "UR5_joint3", sim.simx_opmode_blocking)
err_code, armjoint4_handle = sim.simxGetObjectHandle(
    clientID, "UR5_joint4", sim.simx_opmode_blocking)
err_code, armjoint5_handle = sim.simxGetObjectHandle(
    clientID, "UR5_joint5", sim.simx_opmode_blocking)
err_code, armjoint6_handle = sim.simxGetObjectHandle(
    clientID, "UR5_joint6", sim.simx_opmode_blocking)
# get the handles of hand joints
err_code, endeffector_handle = sim.simxGetObjectHandle(
    clientID, "suctionPad", sim.simx_opmode_blocking)


# set the arm to position control
sim.simxSetObjectIntParameter(
    clientID, armjoint1_handle, 2000, 1, sim.simx_opmode_oneshot)
sim.simxSetObjectIntParameter(
    clientID, armjoint1_handle, 2001, 1, sim.simx_opmode_oneshot)
sim.simxSetObjectIntParameter(
    clientID, armjoint2_handle, 2000, 1, sim.simx_opmode_oneshot)
sim.simxSetObjectIntParameter(
    clientID, armjoint2_handle, 2001, 1, sim.simx_opmode_oneshot)
sim.simxSetObjectIntParameter(
    clientID, armjoint3_handle, 2000, 1, sim.simx_opmode_oneshot)
sim.simxSetObjectIntParameter(
    clientID, armjoint3_handle, 2001, 1, sim.simx_opmode_oneshot)
sim.simxSetObjectIntParameter(
    clientID, armjoint4_handle, 2000, 1, sim.simx_opmode_oneshot)
sim.simxSetObjectIntParameter(
    clientID, armjoint4_handle, 2001, 1, sim.simx_opmode_oneshot)
sim.simxSetObjectIntParameter(
    clientID, armjoint5_handle, 2000, 1, sim.simx_opmode_oneshot)
sim.simxSetObjectIntParameter(
    clientID, armjoint5_handle, 2001, 1, sim.simx_opmode_oneshot)
sim.simxSetObjectIntParameter(
    clientID, armjoint6_handle, 2000, 1, sim.simx_opmode_oneshot)
sim.simxSetObjectIntParameter(
    clientID, armjoint6_handle, 2001, 1, sim.simx_opmode_oneshot)

# get the collision handles
collision_handle_list = []
for i in range(40):
    err_code, collision_handle = sim.simxGetCollisionHandle(
        clientID, "Collision" + str(i), sim.simx_opmode_blocking)
    sim.simxReadCollision(clientID, collision_handle,
                          sim.simx_opmode_streaming)
    collision_handle_list.append(collision_handle)


# function to control the movement of the arm, the input are the angles of joint1, joint2, joint3, joint4, joint5, joint6. The unit are in degrees
def move_arm(armpose, speed):
    '''moves arm'''
    armpose_convert = []
    for i in range(6):
        armpose_convert.append(round(armpose[i]/180 * math.pi, 3))
    sim.simxPauseCommunication(clientID, True)
    sim.simxSetJointTargetPosition(
        clientID, armjoint1_handle, armpose_convert[0], sim.simx_opmode_oneshot)
    sim.simxSetJointTargetPosition(
        clientID, armjoint2_handle, armpose_convert[1], sim.simx_opmode_oneshot)
    sim.simxSetJointTargetPosition(
        clientID, armjoint3_handle, armpose_convert[2], sim.simx_opmode_oneshot)
    sim.simxSetJointTargetPosition(
        clientID, armjoint4_handle, armpose_convert[3], sim.simx_opmode_oneshot)
    sim.simxSetJointTargetPosition(
        clientID, armjoint5_handle, armpose_convert[4], sim.simx_opmode_oneshot)
    sim.simxSetJointTargetPosition(
        clientID, armjoint6_handle, armpose_convert[5], sim.simx_opmode_oneshot)
    sim.simxPauseCommunication(clientID, False)
    time.sleep(speed)

# function to check collision


def check_collision():
    '''checks for collisions along arm'''
    collision_reading = np.zeros(40)
    is_collision = 0
    for j in range(40):
        collision_reading[j] = sim.simxReadCollision(
            clientID, collision_handle_list[j], sim.simx_opmode_buffer)[1]
        if collision_reading[j] == 1:
            is_collision = 1
    if is_collision == 1:
        # print('Collision detected!')
        return 1
    else:
        return 0


# You do not need to modify the code above
def create_ht_matrix(dh_parameters: list):
    '''Creates a homogeneous transformation matrix given an array of DH parameters.'''
    a_alp = dh_parameters[0]
    a_len = dh_parameters[1]
    d_off = dh_parameters[2]
    t_the = dh_parameters[3]

    c_alp = round(np.cos(a_alp), RND)
    s_alp = round(np.sin(a_alp), RND)
    c_the = round(np.cos(t_the), RND)
    s_the = round(np.sin(t_the), RND)

    forward_kinematic_matrix = np.mat([[c_the, round(-s_the*c_alp, RND), round(
        s_the*s_alp, RND), round(a_len*c_the, RND)], [s_the, round(c_the*c_alp, RND), round(
            -c_the*s_alp, RND), round(a_len*s_the, RND)], [0, s_alp, c_alp, round(d_off, RND)], [0, 0, 0, 1]])

    return forward_kinematic_matrix


def gen_ht_matrixe_ur5(joint_angles):
    '''generates "num" number of random homogenous transformation matrixes'''

    link1_alpha = 1.571
    link1_d = 89.2
    link2_a = 425
    link3_a = 392
    link4_alpha = -1.571
    link4_d = 109.3
    link5_alpha = 1.571
    link5_d = 94.75
    link6_d = 82.5

    link7_dh = [3.141, 0, 0, 1.571]
    link7 = create_ht_matrix(link7_dh)

    link1_dh = [link1_alpha, 0, link1_d,
                (joint_angles[0])/57.3 - 1.571]
    link2_dh = [0, link2_a, 0, (joint_angles[1])/57.3 + 1.571]
    link3_dh = [0, link3_a, 0, joint_angles[2]/57.3]
    link4_dh = [link4_alpha, 0, link4_d,
                (joint_angles[3])/57.3 - 1.571]
    link5_dh = [link5_alpha, 0, link5_d, joint_angles[4]/57.3]
    link6_dh = [0, 0, link6_d, joint_angles[5]/57.3]

    arr_of_htms = create_ht_matrix(link1_dh)
    arr_of_htms *= create_ht_matrix(link2_dh)
    arr_of_htms *= create_ht_matrix(link3_dh)
    arr_of_htms *= create_ht_matrix(link4_dh)
    arr_of_htms *= create_ht_matrix(link5_dh)
    arr_of_htms *= create_ht_matrix(link6_dh)
    arr_of_htms *= link7

    return arr_of_htms


def get_dist(pose1, pose2):
    '''returns the summation of differences between the data of Node1 and Node2'''
    mat1 = gen_ht_matrixe_ur5(pose1)
    mat2 = gen_ht_matrixe_ur5(pose2)

    x1 = mat1.item(3)
    y1 = mat1.item(7)
    z1 = mat1.item(11)
    x2 = mat2.item(3)
    y2 = mat2.item(7)
    z2 = mat2.item(11)

    dist = round(math.sqrt(
        math.pow(x1-x2, 2) + math.pow(y1-y2, 2) + math.pow(z1-z2, 2)), 3)

    return dist


def random_pose():
    '''generates arrays of poses which are kept in an array making its a 2d array'''
    pose = []  # type: list[int]
    for i in range(6):
        pose.append(randint(-180, 180))
    return pose


def nearest_neighbor(pose: list[int], tree_list: list[Node]):
    '''returns the node in tree "nearest" to rand_pose'''
    min_dist = 3000000
    for nodes in tree_list:
        node_dist = get_dist(nodes.data, pose)
        if node_dist < min_dist:
            min_dist = node_dist
            node = nodes
    return node


def limit_distance(rand_pose, near_pose, speed):
    '''returns a distance pose with each angle 3 degrees
    or less closer to near_pose from rand_pose'''
    dist_angls = []  # type: list[int]
    for index in range(len(rand_pose)):
        diff = rand_pose[index] - near_pose[index]
        if diff > speed or diff < -speed:
            dist_angls.append(diff/abs(diff)*speed)
        else:
            dist_angls.append(diff)
    return dist_angls


def within_range(range: float, pose1: list, pose2: list):
    '''checks to see if those poses are within range of eachother'''
    poses_dist = get_dist(pose1, pose2)
    if poses_dist <= range:
        return True
    else:
        return False


def add_poses(pose1: list, pose2: list):
    '''sum poses'''
    sum_pose = []  # type: list[int]
    for index in range(len(pose1)):
        sum_pose.append(pose1[index] + pose2[index])
    return sum_pose


def get_all_nodes(node: Node, all_nodes: list):
    all_nodes.append(node)
    for child in node.children:
        get_all_nodes(child, all_nodes)
    return all_nodes


'''
n = Node(1, None, None)
n.add_child(Node(2, None, None))
m = Node(3, None, None)
m.add_child(Node(4, None, None))
m.add_child(Node(5, None, None))
m.add_child(Node(6, None, None))
n.add_child(m)
lst = []  # type: list[Node]
lst = get_all_nodes(n, lst)

for elem in lst:
    print(str(elem.tag))
'''


def generate_rrt(starting_pose: list[int], goal_pose: list[int], mx_ang_chg, gl_catch_rnge, mx_nodes):
    '''uses a tree to randomly explore a UR5 workspace so that it reaches some goal pose'''

    global NODE_NUM

    NODE_NUM = 1
    initial_node = Node(NODE_NUM, None, starting_pose)

    testing_arm_spd = 0

    while True:
        node_list = []  # type: list

        rand_pose = random_pose()
        nearest_node = nearest_neighbor(
            rand_pose, get_all_nodes(initial_node, node_list))

        nearest_pose = nearest_node.data

        branch = limit_distance(rand_pose, nearest_pose, mx_ang_chg)

        new_pose = add_poses(nearest_pose, branch)
        move_arm(new_pose, testing_arm_spd)

        #print("Random Node:    /t/t" + str(rand_pose))
        # print("Nearest Node:   " + str(nearest_node.tag) +
        #      "/tNode Pose:" + str(nearest_pose))
        #print("Limited Vecotor:/t/t" + str(branch))
        #print("New Node:       /t/t" + str(new_pose))
        #print("Goal Node:      /t/t" + str(goal_pose))
        # print()

        if check_collision() == 0:
            NODE_NUM += 1
            new_node = Node(NODE_NUM, nearest_node, new_pose)
            nearest_node.add_child(new_node)

            if within_range(gl_catch_rnge, new_pose, goal_pose):
                print("Node Within Goal's Range " + str(new_node.data))
                new_node = Node(NODE_NUM + 1, new_node, goal_pose)
                print("Node Within Goal's Range " + str(new_node.data))
                break
        else:
            move_arm(nearest_pose, testing_arm_spd)

        if NODE_NUM >= mx_nodes:
            break

    return [initial_node, new_node]


def RRT_travers_to_goal(start, goal):
    '''a UR5 robot heads from starting pose to goal pose'''

    max_pose_angle_change = 3
    goal_catch_dist = 20
    max_num_nodes_in_tree = 100

    global PATH

    # create a tree of 100 nodes starting at the starting pose

    frst_lst_nodes = generate_rrt(
        start, goal, max_pose_angle_change, goal_catch_dist, max_num_nodes_in_tree)
    #       print(str(frst_lst_nodes[0].data) + " " + str(frst_lst_nodes[1].data))

    # find the node nearest to goal, create a new tree starting at the nearest node to goal

    if (str(frst_lst_nodes[1].data) != str(goal)):
        print("Last Node in Tree NOT EQUAL Goal Node")
        print("Goal Node: " + str(goal))
        tree_array = []
        tree_array = get_all_nodes(frst_lst_nodes[0], tree_array)
        nearest = nearest_neighbor(goal, tree_array)
        PATH.append(nearest)
        print("Nearest Node: " + str(nearest.data))
        print("Distance Between: " + str(get_dist(nearest.data, goal)))
        print()
        last_node = RRT_travers_to_goal(nearest.data, goal)
        if str(last_node.data) == str(goal):
            PATH.append(last_node)

    return frst_lst_nodes[1]


def RRT_show_path(start, goal):
    '''displays a path from start to goal in a systematic manner after creating a path using an RRT method'''

    global PATH

    arm_spd = 1
    finished_path = []

    curr_node_in_path = RRT_travers_to_goal(goal, start)

    if str(curr_node_in_path.data) == str(start):
        while str(curr_node_in_path.data) != str(goal):
            finished_path.append(curr_node_in_path.data)
            print(curr_node_in_path.data)
            move_arm(curr_node_in_path.data, arm_spd)
            curr_node_in_path = curr_node_in_path.parent
        finished_path.append(curr_node_in_path.data)
        print(curr_node_in_path.data)
        move_arm(curr_node_in_path.data, arm_spd)
    else:
        curr_node_in_path = PATH.pop()
        while str(curr_node_in_path.data) != str(goal):
            if curr_node_in_path.tag == 1 and len(PATH) > 0:
                curr_node_in_path = PATH.pop()
            else:
                finished_path.append(curr_node_in_path.data)
                print(curr_node_in_path.data)
                move_arm(curr_node_in_path.data, arm_spd)
                curr_node_in_path = curr_node_in_path.parent
        finished_path.append(curr_node_in_path.data)
        print(curr_node_in_path.data)
        move_arm(curr_node_in_path.data, arm_spd)

    return finished_path


starting_pose = [0, 0, 0, 0, 0, 0]
#ending_pose = [9, 9, 9, 9, 9, 9]
ending_pose = [90, 90, 0, 0, 0, 0]
RRT_show_path(starting_pose, ending_pose)

#generate_rrt(starting_pose, ending_pose, 3, 100, 100)

print('Program ended')
